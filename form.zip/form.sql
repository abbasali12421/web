-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2024 at 03:01 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `form`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', 'admin', 'admin@admin.com');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(255) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `author` varchar(1000) NOT NULL,
  `date` date NOT NULL,
  `dater` date NOT NULL,
  `book_url` varchar(1000) NOT NULL,
  `price` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `img` varchar(1000) NOT NULL,
  `pdf` varchar(1000) NOT NULL,
  `size` mediumtext NOT NULL,
  `count` mediumtext NOT NULL,
  `filename` mediumtext NOT NULL,
  `type` mediumtext NOT NULL,
  `class` varchar(255) NOT NULL,
  `subclass` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `service` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `date`, `dater`, `book_url`, `price`, `description`, `img`, `pdf`, `size`, `count`, `filename`, `type`, `class`, `subclass`, `subject`, `service`) VALUES
(8, 'The Book Of Tawjeeh', 'Abbas', '2024-09-18', '2024-09-01', 'none', 'free', 'this is our book that can make u feel happy', 'Security Matrix.png', 'Black Hat Bash.pdf', '', '', '', '', 'mid1', 'mid1', 'fr', 'book'),
(9, 'the hamster', 'any', '2024-09-18', '2024-09-19', 'none', 'free', 'nknknknm', 'Security Matrix.png', 'Cybersecurity Career Roadmap.pdf', '', '', '', '', 'middle', 'pre-2', 'الرياضيات', '');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(255) NOT NULL,
  `title` varchar(1000) NOT NULL,
  `author` varchar(1000) NOT NULL,
  `date` varchar(255) NOT NULL,
  `img` varchar(10000) NOT NULL,
  `content` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `author`, `date`, `img`, `content`) VALUES
(16, 'post 6', 'taha', '2024-09-13', '66e7853e9134c.PNG', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(17, 'post 7', 'abbas', '2024-09-13', '66e78551e2d2c.png', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(18, 'post 8', 'mahmoud', '2024-09-13', '66e785633eef6.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(19, 'post 9', 'mahmoud', '2024-09-13', '66e7882753661.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(20, 'post 10', 'mahmoud', '2024-09-13', '66e7882d0ffa8.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(21, 'post 11', 'taha', '2024-09-13', '66e788339a4f6.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(22, 'post 12', 'taha', '2024-09-13', '66e78837f1c9b.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(24, 'post 14', 'taha', '2024-09-13', '66e788400354c.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(25, 'post 15', 'taha', '2024-09-13', '66e78845112c2.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(27, 'post 17', 'taha', '2024-09-13', '66e7884e130df.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(28, 'post 18', 'taha', '2024-09-13', '66e788525d245.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(29, 'post 19', 'taha', '2024-09-13', '66e78856aefe1.jpg', '<p>post 1 post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1post 1</p>\r\n'),
(32, 'Why we Using internet', 'Abbas', '2024-09-18', '66eb5f0c421a5.jpg', '<h1 id=\"why-we-use-\">Why We Use ?</h1>\r\n<p><br></p>\r\n<p><hr><br><strong>We Are in Iraq And We Live In There</strong></p>\r\n<p>We Have This Lists :</p>\r\n<ol>\r\n<li>i eat</li>\r\n<li>i swim</li>\r\n<li>this</li>\r\n<li>this is my world</li>\r\n</ol>\r\n<p>ok</p>\r\n<ul>\r\n<li>this</li>\r\n<li>is</li>\r\n<li>my</li>\r\n<li>points</li>\r\n<li>word</li>\r\n<li>word6<blockquote>\r\n<p>make Your Life Good Bro At This Point<br><br><br>i Eate Frutes Every Day<br><br></p>\r\n</blockquote>\r\n</li>\r\n</ul>\r\n<p><br></p>\r\n<p>the World Of Hacking IS Unknown</p>\r\n'),
(33, 'koko', 'رقلقلق', '2024-09-17', '66eb65df41250.jpg', '<p>قلقلقلق</p>\r\n'),
(34, 'koko', 'رقلقلق', '2024-09-17', '66eb65ed285bd.jpg', '<p>قلقلقلق</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `id` int(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `class` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `fname`, `lname`, `email`, `password`, `city`, `img`, `description`, `class`) VALUES
(1, 'ahmed', 'sama', 'sama@gmail.com', '$2y$10$X0KmXAnqGZ8d3NZfFpFqWuSdOv4B7AqXbMavFRA71.9rOSQ6MoCK.', 'البصرة', '', '', ''),
(2, 'soso', 'sama', 'samasoso@gmail.com', '$2y$10$hkXULWWCcS9SS3Gf.Clqp.K4C0QHcJ/Qyzt5n5GLUH1ufv48RaVs2', 'البصرة', '', '', ''),
(3, 'taha', 'mohamed', 'taha@gmail.com', '$2y$10$up/nKti/RtKjaA7TjumdtuFNpX0EojNcrWb/bMIffsIp0hMRAsPk6', 'البصرة', '', '', ''),
(4, 'hosam', 'hosam', 'hosam@gmail.com', '$2y$10$1g6Odeom3EB7cAXMEXERFuh0EyHhymUvmZNwGEGJp3VfLrxFyomxq', 'بابل', '', '', ''),
(5, 'hiddem', 'hiddes', 'hiddem@g.g', '$2y$10$SL8o/pG6.NeBW3.dMfwsRur2NjzJtTo9hG/toiAmKKPiJXv061DyK', 'ذي قار', '', '', ''),
(6, 'abbas', 'aa', 'john1999gt@gmail.com', '$2y$10$I.QAGYRZRpI60r76DXTZx.0niPWn14u3Qb0iFwQ3bIhEqfyvrG4vG', 'ذي قار', '', '', ''),
(7, 'ahmedsultan', 'ahmedsultan', 'ahmedsultan@gmail.com', '$2y$10$wMeemVxdLg0JT2rmgBb34e.LHzuYKCX0HOqwRTUNSFjcRrFULqXeG', 'ذي قار', '', '', ''),
(8, 'ali', 'ali', 'ali@gmail.com', '$2y$10$AzpRfDlG6P56/loMmOic9.f18.LlnMBqW1oYFEB6OQB/qKhclu.Tu', 'None', '', '', ''),
(9, 'lol', 'lol', 'tahaelostora371@gmail.com', '$2y$10$JMplJZB6gupj.P257cjG4.U5am/JWY0kRn4rqtjdQqjEAmlrl7Hkm', 'None', '', '', ''),
(10, 'updates', 'update', 'updates@g.com', '$2y$10$BoXrj1wDPIdYsuAUdcgf4uRQJHGzuX81FfDZK0sUCff/yIhdymRG.', 'None', 'photo_2024-07-26_17-18-06.jpg', 'loleta', ''),
(11, 'Taha', 'mohamed', 'gokhib71@gmail.com', '$2y$10$2lAwHLJa1BqpaoaxRNf/bOKlvg4hYU0lwcYB0YHfmeC28BhzZVXbC', 'None', 'photo_2024-07-26_17-18-06.jpg', '', ''),
(12, 'ahemd', 'ahemd', 'ahemd@gmail.com', '$2y$10$g2lpatAq09G.5Dlmyb806OoBC3hnIo/tpliFvFSqMXf5mPL9o4osW', 'None', 'photo_2024-09-13_04-23-13.jpg', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `reg`
--
ALTER TABLE `reg`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
