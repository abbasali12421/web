<?php
session_start();

// Include the database connection file
include '../config.php';

// Initialize error message variable
if (!isset($_SESSION['error_message'])) {
    $_SESSION['error_message'] = '';
}

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $email = $_POST['mail'];
    $password = $_POST['pass'];

    // Use prepared statement to prevent SQL injection
    $sql = "SELECT * FROM `reg` WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email); // Bind email parameter
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $stored_hash = $row['password'];

        // Verify the input password against the stored hash
        if (password_verify($password, $stored_hash)) {
            // Password is valid, proceed with login
            $encoded_email = base64_encode($email);
            $_SESSION['username'] = $encoded_email;

            // Redirect and clear any existing error message
            $_SESSION['error_message'] = '';
            header('Location: /profile/profile.php');
            exit;
        } else {
            // Password is invalid, set error message
            $_SESSION['error_message'] = 'Invalid Credentials: Your username or password are incorrect.';
        }
    } else {
        // Handle SQL errors
        $_SESSION['error_message'] = mysqli_error($conn);
    }

    // Redirect to avoid form resubmission issues
    header('Location: login.php');
    exit;
}


// Input validation
$email = filter_input(INPUT_POST, 'mail', FILTER_VALIDATE_EMAIL);
$password = filter_input(INPUT_POST, 'pass', FILTER_SANITIZE_STRING);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/style/login.css">
    <title>Tawjeeh - Login Now</title>
</head>
<body>
<?php if (!empty($_SESSION['error_message'])) { ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <strong><?php echo htmlspecialchars($_SESSION['error_message']); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php
    // Clear the error message after displaying it
    $_SESSION['error_message'] = '';
    ?>
<?php } ?>

<div class="login-panel">
    <div class="container">
        <div class="form-controls">
            <!-- create Inputs -->
            <div class="title">
                <img src="/static/icons/Book.webp" width="20" alt="error">
                <span>Tawjeeh</span>
            </div>
            <div class="description">
                <p>
                    Welcome Back , Please login to <br> your account
                </p>
            </div>
            <div class="login-btns">
                <button class="btn btn-google"><i class="fab fa-google"></i><span>Login With Google </span></button>
                <button class="btn btn-facebook"><i class="fab fa-facebook-f"></i><span>Login With Facebook </span></button>
            </div>
            <div class="move-line">
                <span class="or-line-left"></span>
                <p class="or-line">OR</p>
                <span class="or-line-right"></span>
            </div>
            <form action="login.php" method="post">
                <div class="form-inputs">
                    <input required type="text" name="mail" id="email">
                    <label for="email">Email Address/Username</label>
                </div>
                <div class="form-inputs">
                    <input required type="password" name="pass" id="password">
                    <label for="password">Password</label>
                </div>
                <div class="rem">
                   <div class="forms-check">
                    <input type="checkbox" name="remember" id="check">
                    <label for="check">Remember me</label>
                   </div>
                   <div>
                     <a href="#">Forget Password ?</a>
                   </div>
                 </div>
                 <div class="form-buttons">
                     <button type="submit" name="submit">Login</button>
                     <button onclick="window.location.href='/page/register.php'">Sign Up</button>
                 </div>
                 <div>
                    <br><br>
                    <p>By Signing up, you agree to Tawjeeh's <br> <a style="text-decoration: underline;" href="#">Terms and Conditions</a> & <a style="text-decoration: underline;" href="#">Privacy Policy</a></p>
                 </div>
            </form>
        </div>
    </div>
    <div class="desgin-panel">
        <div class="btn-return">
            <!-- change Page Name -->
            <button class="return" onclick="window.location.href='/../index.php'"><i class="fa-solid fa-angle-left"></i> Back</button>
        </div>
        <div class="words">
            <h1>Welcome My Brother</h1>
            <h1>You Are Not Know About service us ?</h1>
            <br><br>
            <p>Go To Home Page and Read About My Services, if you want that<br> please click on home</p>
            <br><br>
            <a href="../index.php#service"><Button><i class="fas fa-home"></i></Button></a>
        </div>
    </div>
</div>
<script src="/js/submit.js"></script>
</body >
</html>