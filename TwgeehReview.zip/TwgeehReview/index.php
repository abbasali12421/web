<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="style/style.css">
  <style>
    .contact-telegram {
      display: flex;
      flex-direction: column;
      align-items: center;
      background-color: rgb(87, 87, 248);
      backdrop-filter: blur(8px);
      margin: 100px;
      border-radius: 8px;
      padding: 15px;
    }

    .contact-telegram .logo i {
      font-size: 5em;
      color: #ffffff;
      margin-bottom: 15px;
    }
  </style>
  <title>Tawjeeh Review - all Reviews</title>
</head>

<body>
  <header class="toolbar">
    <div class="navbar">
      <div class="logo">

        <h1 class="logo-title">Twajeeh Education</h1>
      </div>
      <div class="menu-mobile">
        <div class="menu-click">
          <button id="menuOpen"><i class="fas fa-bars"></i></button>
        </div>
      </div>
      <div class="items">
        <ul>
          <li><a href="blog.php" class="link">المدونة</a></li>
          <li><a href="" class="link">الارشيف</a></li>
          <li><a href="#" class="link">حول المنصة</a></li>
          <li><a href="timer.php" class="link">الوقت المتبقي للامتحانات الوزارية</a></li>
        </ul>
      </div>
      <div class="login">
        <a class="link" href="/page/login.php">login</a>
        <a href="/page/register.php"><button class="btn btn-primary">Sign up</button></a>
      </div>
    </div>
    <div class="menu">
      <ul class="menu-items">
        <li><a href="#" class="link">Blog</a></li>
        <li><a href="#" class="link">Archive</a></li>
        <li><a href="#" class="link">About</a></li>
      </ul>
      <button class="menu-btn-sign-up">Sign up</button>
      <button class="menu-btn-login">Login</button>
    </div>

  </header>
  <section class="landing">
    <div class="description">
      <h1 class="description-header">توجيه : أدوات تعلم مبتكرة لنجاح أكاديمي متميز</h1>
      <p class="mini-desc">
        <span>تأسست منصة توجيه لتكون شريكًا رئيسيًا في رحلتك الأكاديمية، سواء كنت في </span>
        <br>
        <span>مرحلة المدرسة أو الجامعة. نحن هنا لمساعدتك في تحقيق أهدافك التعليمية</span>
        <br>
        <span>والمهنية من خلال تقديم مجموعة شاملة من الخدمات </span>
        <span>خدماتنا تشمل مراحل الابتدائية والمتوسطة والاعدادية</span>
        <span>الكتب والملازم والاسئلة والملخصات واالاختبارات تجدهاهنا</span>
      </p>
      <div class="mobile-center">
        <a href="#class"><button class="mobile-center btn btn-primary">Get Started</button></a>
      </div>

    </div>
    <div class="landing-images">
      <img class="lang-image" src="/static/backgrounds/landing.webp">
    </div>


  </section>
  <div class="services">
    <div class="title">
      <h1 id="service">Our Services</h1>
    </div>
    <div class="cards">
      <div class="card">
        <img src="/static/images/6725166.webp" width="450">
        <div class="card-text">
          نوفر لك أفضل الملازم والمراجعات لكل المراحل الدراسية
        </div>
      </div>
      <div class="card">
        <img src="/static/images/edu.webp" width="450">
        <div class="card-text">
          اختر من بين مجموعة واسعة من الصفوف التعليمية المتاحة لدينا
        </div>
      </div>
      <div class="card">
        <img src="/static/images/hand.webp" width="450">
        <div class="card-text">
          نضمن لك سرعة الرد والتعامل الفوري مع استفساراتك
        </div>
      </div>
    </div>
    <div class="contact">
      <div class="contact-us-text">
        <h1 style="margin-bottom: 2cqmax;">Contact Us</h1>
        <ul>

          <li><i class="fab fa-whatsapp"></i> Call Us By Telegram : <span class="item-number"><a style="color: #6d5ae9"
                class="link" href="https://t.me/ContactTawjeehBot">@ContactTawjeehBot</a></span></li>
          <li><i class="fa-solid fa-envelope"></i> Call Us By Email: <span class="item-email"><a style="color: #6d5ae9"
                class="link" href="mailto:edutawjeeh1@gmail.com">edutawjeeh1@gmail.com</a></span></li>
        </ul>
        <div class="img-contact">
          <img src="/static/images/man-sits-desk-with-computer-notepad-with-picture-man-working-it.webp" />
        </div>
      </div>
      <div class="form">
        <div class="form-title">
          <h1>Contact US By Email</h1>
          <p class="brown">We’re here to help! <br>Reach out to us now for the support you need</p>
        </div>
        <form action="" method="post">
          <label for="fname">FirstName</label>
          <input type="text" name="" id="fname">
          <label for="lname">LastName</label>
          <input type="text" name="" id="lname">
          <label for="email">Email</label>
          <input type="email" name="" id="email">
          <label for="phone">Phone</label>
          <input type="tel" name="" id="phone" autocomplete="tel">
          <label for="subject">Subject</label>
          <input type="text" name="" id="subject">
          <label for="message">Message</label>
          <textarea rows="7" name="" id="message"></textarea>
          <button class="contact-btn btn">SEND</button>

        </form>
      </div>
    </div>
  </div>
  <!-- classes parts -->
  <div class="classes">
    <h1>Our Classes</h1>
    <div class="universty">
      <div class="cards">
        <div class="card" style="border:1px solid rgba(243, 12, 212, 0.466)">
          <img src="/static/class/uni.avif" width="450">
          <div class="card-text" style="font-weight: bold;color: rgba(168, 65, 5, 0.623);">المرحلة الابتدائية</div>
          <div class="card-text">
الكتب والملازم والمحاضرات للمراحل الابتدائية الاولى الستة , والوزاريات والملخصات والامتحانات لطلبة السادس الابتدائي
        </div>
          <div class="links" style="margin-top: 10px;"><br>
            <button class="card-text btn contact-btn" onclick="window.location = '/class/الابتدائي.html' ">تصفح الان هذا القسم</button>

          </div>
        </div>
        <div class="card" id="class">
          <img src="/static/class/uni.avif" width="450">
          <div class="card-text" style="font-weight: bold;color: rgba(168, 65, 5, 0.623);">المرحلة الاعدادية</div>
          <div class="card-text">
            تشمل الرابع والخامس والسادس بفرعيه الادبي والعلمي , الوزاريات والمخلصات والامتحانات والاختبارات لكل المواضيع والافصل والحلول الوزارية في السادس الاعدادي هنا تجدها 
          </div>
          <div class="links">
            <button class="card-text btn contact-btn" onclick="window.location = '/class/الاعدادي.html' ">تصفح الان هذا القسم</button>

          </div>

        </div>
        <div class="card">
          <img src="/static/class/4133a3a3-5373-4002-8ac8-884d4e39cce0.png" width="450">
          <div class="card-text" style="font-weight: bold;color: rgba(168, 65, 5, 0.623);">المرحلة المتوسطة</div>
          <div class="card-text">
           هنا ستجد كافة الكتب والملازم والاسئلة اليومية والشهرية نصف السنة والنهائية لكل المراحل من الاول الى الثالث المتوسط بما فيها الوزاريات والنسخ الوزارية والمراجعات والشروحات 

          </div>
          <div class="links">
            <button class="card-text btn contact-btn" onclick="window.location = '/class/المتوسط.html' ">تصفح الان هذا القسم</button>

          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="how">
    <div class="how-to-title">
      <h1>Subscribe
      </h1>
    </div>
    <div class="sections">
      <div class="section">
        <i class="fa-solid fa-right-to-bracket"></i>
        <p>Create Account</p>
      </div>
      <div class="section">
        <i class="fa-solid fa-arrow-pointer"></i>
        <p>Select Book Or References</p>
      </div>
      <div class="section">
        <i class="fa-regular fa-credit-card"></i>
        <p>Paymet</p>
      </div>
    </div>
  </div>

  <div style="cursor: pointer;" class="contact-telegram" onclick="window.location='https://t.me/eduTawjeeh'">
    <div class="logo">
      <i class="fab fa-telegram"></i>
    </div>
    <div class="content-telegram-contact">
      <h1 style="color: white;">Join To Telegram Us</h1>
    </div>
  </div>

  <div class="footer">
    <div class="part-logo">
      <div class="logo-footer">
        <img src="/static/images/log.webp" width="80" style="border-radius: 50%;">
        <span><b>Tawjeeh</b> Education</span>
      </div>
      <div class="logo-description">
        <p>Get All References By Fast And Simply</p>
        <p> we are striving to provide the best learning material on <br>technical and non-technical subjects.</p>
        <div class="copyright">
          <p>© Twajeeh 2024 -
            <?php echo date('Y')?>
          </p>
        </div>
      </div>
      <div class="social">
        <i onclick="window.location ='https://www.facebook.com/profile.php?id=61560868892128&mibextid=ZbWKwL' "
          class="fab fa-facebook"></i>
        <i onclick="window.location='https://www.instagram.com/edutawjeeh?igsh=Mnd2Ymhodzc1enE5'"
          class="fab fa-instagram"></i>
        <i onclick="window.location='https://t.me/eduTawjeeh'" class="fab fa-telegram"></i>
        <!-- <i class="fab fa-twitter"></i> -->
        <i onclick="window.location = 'https:\/\/www.youtube.com/@EduTawjeeh'" class="fab fa-youtube"></i>
        <i onclick="document.location.href = 'https:\/\/tiktok.com/@Edutawjeeh'" class="fab fa-tiktok"></i>
        <i onclick="window.location = 'https:\/\/www.x.com/@EduTawjeeh'" class="fab fa-twitter"></i>
      </div>
    </div>
    <div class="classes">
      <h1>الصفوف </h1>
      <a href="/class/الاعدادي.html" class="link" style="color:white">السادس العدادي</a>
      <a href="/class/الابتدائي.html" class="link" style="color:white">الثالث المتوسط</a>
      <a href="/class/الابتدائي.html" class="link" style="color:white">السادس االبتدائي</a>

    </div>
    <div class="contact-us">
      <h1>تواصل </h1>

      <a href="mailto:edutawjeeh1@gmail.com" style="color:white" class="link">عبر الايميل</a>
      <a href="https://t.me/ContactTawjeehBot" style="color:white" class="link">عبر التيليجرام</a>

    </div>

  </div>
  <script src="js/submit.js"></script>
  <script src="js/select.js"></script>
  <script src="js/addition.js"></script>
</body>

</html>