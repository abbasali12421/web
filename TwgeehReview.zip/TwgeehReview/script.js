$(document).ready(function() {
    $('#search-input').on('keyup', function() {
        let query = $(this).val().trim();
        if (query.length > 0) {
            $.ajax({
                url: 'search.php', // Ensure this file handles the search logic
                method: 'POST',
                data: { search: query },
                success: function(data) {
                    $('#post-container').html(data);
                },
                error: function() {
                    $('#post-container').html('<p>An error occurred. Please try again.</p>');
                }
            });
        } else {
            // Optionally reset to original posts when input is empty
            $.ajax({
                url: 'search.php',
                method: 'POST',
                data: { search: '' },
                success: function(data) {
                    $('#post-container').html(data);
                }
            });
        }
    });
});
