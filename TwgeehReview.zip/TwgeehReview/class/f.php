<?php
header('Content-Type: text/html; charset=UTF-8');
require_once 'config.php'; // Database connection

// Get the book ID from the URL parameter
$book_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch book data from the database
$query = $conn->prepare("SELECT * FROM books WHERE id = ?");
$query->bind_param("i", $book_id);
$query->execute();
$result = $query->get_result();
$book = $result->fetch_assoc();

if (!$book) {
    echo "Book not found.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($book['title']); ?></title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      margin: 0;
      padding: 20px;
      display: flex;
      flex-direction: column; /* جعل التخطيط عمودياً */
      align-items: center; /* توسيط المحتوى */
    }
    body {
  direction: rtl; /* اجعل اتجاه النصوص على مستوى الصفحة بالكامل من اليمين إلى اليسار */
  text-align: right; /* اجعل المحاذاة للنصوص من اليمين */
}

/* يمكن أيضًا تخصيص بعض الصناديق أو النصوص فقط إذا كنت لا تريد تطبيق التغيير على كل الصفحة */
    .book-info, .description-box, .modal-content {
  direction: rtl; /* اتجاه النصوص من اليمين لليسار */
  text-align: right; /* محاذاة النصوص لليمين */
}
.buttons {
  display: flex;
  gap: 10px;
  margin-top: 20px;
  margin-right: auto; /* لضبط الأزرار باتجاه اليمين */
}


    /* تنسيق صندوق المحتوى */
    .content {
      width: 100%;
      max-width: 800px; /* تحديد عرض أقصى لصندوق المحتوى */
    }

    .book-title-under-image {
    text-align: center; /* توسيط العنوان */
    margin-top: 10px; /* إضافة مسافة فوق العنوان */
    margin-bottom: 10px; /* إضافة مسافة أسفل العنوان */
}

.book-title-under-image h2 {
    font-size: 20px; /* حجم الخط */
    color: #333; /* لون الخط */
    margin: 0; /* إزالة المسافات */
}


    .download-box, .description-box {
      background-color: rgba(255, 255, 255, 0.8);
      border: 1px solid #ccc;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      padding: 20px;
      margin-bottom: 20px;
      width: 100%;
      box-sizing: border-box;
    }

    .download-box {
      display: flex;
      flex-direction: row-reverse;
      align-items: flex-start;
      gap: 20px;
    }

    .download-box img {
      max-width: 150px;
      border-radius: 10px;
    }

    .download-box .book-info {
      flex: 1;
      text-align: right;
    }

    .download-box h1, .download-box h2, .download-box h3, .download-box p {
      margin: 0;
    }

    .download-box h1 {
      font-size: 34px;
      margin: 20px 0 10px;
      color: #333; /* لون النص */
    }

    .download-box h2 {
      font-size: 20px;
      color: #4CAF50; /* لون خاص */
      margin: 0 0 10px;
    }

    .download-box h3 {
      font-size: 18px;
      color: #888; /* لون رمادي */
      margin: 0 0 20px;
    }

    .download-box p {
      font-size: 15px;
      color: #444; /* لون النص */
      margin: 5px 0;
    }

    .buttons {
      display: flex;
      gap: 10px;
      justify-content: flex-end;
      margin-top: 20px;
    }

    .download-button, .share-button, .copy-button {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 10px 15px;
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 14px;
      cursor: pointer;
      border-radius: 5px;
    }

    .share-button {
      background-color: #2196F3;
    }

    .copy-button {
      background-color: #FFA500; /* لون مختلف لزر النسخ */
    }

    .full-description {
      margin-top: 30px;
    }

    .description-box h2 {
      font-size: 24px;
    }

    .description-box p {
      font-size: 15px;
      color: #444;
      text-align: right;
    }
    .title-description-bx {
        text-align: right;
    }
    /* تنسيق النافذة المنبثقة */
    /* <a href="/admin/uploads/' . htmlspecialchars($book['pdf']) . '" target="_blank" class="btn btn-primary">Download PDF</a>                  */
    .modal {
      display: none; /* البداية مخفية */
      position: fixed;
      z-index: 1;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0, 0, 0, 0.6); /* جعل الخلفية أغمق */
      padding-top: 60px;
    }

    .modal-content {
      background-color: #fff; /* لون الخلفية للنافذة */
      margin: 5% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 60%; /* عرض النافذة أقل */
      max-width: 300px; /* عرض أقصى للنافذة */
      border-radius: 15px; /* زوايا مدورة */
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); /* تأثير الظل */
    }

    .modal-content h3 {
      margin: 0 0 15px; /* مسافة تحت العنوان */
      font-size: 24px; /* زيادة حجم خط العنوان */
      color: #333; /* لون خط العنوان */
      text-align: center; /* توسيط العنوان */
    }

    /* تعديل الزر */
    .modal-content button {
      background-color: transparent; /* خلفية شفافة */
      border: none; /* إزالة الحدود */
      color: #007BFF; /* لون النص */
      font-size: 16px; /* زيادة حجم الخط */
      cursor: pointer; /* تغيير المؤشر عند التمرير */
      padding: 10px; /* مساحة داخلية */
      width: 100%; /* عرض 100% */
      margin: 5px 0; /* مسافة فوق وتحت */
      transition: color 0.3s; /* تأثير عند تغيير اللون */
    }

    /* تأثير عند تمرير الماوس */
    .modal-content button:hover {
      color: #0056b3; /* تغيير اللون عند التمرير */
    }

    /* فصل الأزرار بخط */
    .modal-content button + button {
      border-top: 1px solid #ddd; /* خط بين الأزرار */
      margin-top: 10px; /* مسافة فوق الخط */
    }

    /* تأثير الجمال */
    .modal-content {
      border-radius: 20px; /* زوايا مدورة أكثر */
    }

    /* تنسيق شعارات مواقع التواصل الاجتماعي */
    .social-icon {
      width: 24px; /* عرض الشعارات */
      vertical-align: middle; /* توسيط العمودي */
      margin-left: 5px; /* مسافة بين الشعارات */
    }

  </style>
</head>
<body>

  <div class="content">
    <div class="download-box">
      <div class="book-image">
        <img src="/admin/uploads/<?php echo htmlspecialchars($book['img']); ?>" alt="صورة الكتاب">
        <div class="book-title-under-image">
          <h2><?php echo htmlspecialchars($book['title']); ?></h2>
        </div>
      </div>

      <div class="book-info">
        <h1><?php echo htmlspecialchars($book['title']); ?></h1>
        <h3>تحميل كتاب <?php echo htmlspecialchars($book['title']); ?></h3>
        <p><strong>المادة:</strong> <?php echo htmlspecialchars($book['filename']); ?></p>
        <p><strong>المرحلة الدراسية:</strong> <?php echo htmlspecialchars($book['class']); ?></p>
        <p><strong>الوصف:</strong> <?php echo htmlspecialchars($book['description']); ?></p>
        <p><strong>إعداد:</strong> <?php echo htmlspecialchars($book['author']); ?></p>
        <p><strong>عدد الصفحات:</strong> <?php echo htmlspecialchars($book['count']); ?></p>
        <p><strong>حجم الملف:</strong> <?php echo htmlspecialchars($book['size']); ?></p>
        <p><strong>نوع الملف:</strong> <?php echo htmlspecialchars($book['type']); ?></p>
        <p><strong>تاريخ الإصدار:</strong> <?php echo htmlspecialchars($book['dater']); ?></p>

        <div class="buttons">
          <button class="copy-button" onclick="copyLink()">نسخ الرابط</button>
          <button class="share-button" onclick="showModal()">مشاركة</button>
          <button class="download-button">
            <a href="/admin/uploads/<?php echo htmlspecialchars($book['pdf']); ?>" target="_blank">تحميل</a>
          </button>
        </div>
      </div>
    </div>

    <div class="description-box">
      <h2 class="title-description-bx">الوصف الكامل للكتاب</h2>
      <p><?php echo htmlspecialchars($book['description']); ?></p>
    </div>
  </div>

  <!-- Modal for sharing options -->
  <!-- Your modal HTML here -->
  <div class="modal" id="shareModal">
    <div class="modal-content">
      <h3>اختر المنصة التي تريد أن تشارك بها الصفحة</h3>
      <button onclick="shareOnTelegram()">تليكرام <img src="https://pngimg.com/uploads/telegram/telegram_PNG12.png" class="social-icon" alt="تليكرام"></button>
      <button onclick="shareOnWhatsApp()">واتساب <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" class="social-icon" alt="واتساب"></button>
      <button onclick="shareOnInstagram()">إنستغرام <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" class="social-icon" alt="إنستغرام"></button>
      <button onclick="shareOnFacebook()">فيسبوك <img src="https://upload.wikimedia.org/wikipedia/commons/5/51/Facebook_f_logo_%282019%29.svg" class="social-icon" alt="فيسبوك"></button>
      <button class="copy-button" onclick="copyLink()">نسخ الرابط</button> <!-- زر نسخ الرابط -->
      <button onclick="closeModal()">إغلاق</button>
    </div>
  </div>
  <script>
    function showModal() {
        document.getElementById("shareModal").style.display = "block"; // Show the modal
    }

    function closeModal() {
        document.getElementById("shareModal").style.display = "none"; // Close the modal
    }

    function shareOnTelegram() {
        const url = window.location.href;
        const telegramUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}`;
        window.open(telegramUrl, '_blank');
        closeModal(); // Close modal after sharing
    }

    function shareOnWhatsApp() {
        const url = window.location.href;
        const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(url)}`;
        window.open(whatsappUrl, '_blank');
        closeModal(); // Close modal after sharing
    }

    function shareOnInstagram() {
        alert('يمكنك مشاركة الرابط في إنستغرام.');
        closeModal(); // Close modal after alert
    }

    function shareOnFacebook() {
        const url = window.location.href;
        const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        window.open(facebookUrl, '_blank');
        closeModal(); // Close modal after sharing
    }

    function copyLink() {
        const url = window.location.href;
        navigator.clipboard.writeText(url).then(() => {
            alert('تم نسخ الرابط بنجاح!');
        }).catch(() => {
            alert('فشل نسخ الرابط.');
        });
    }
</script>


</body>
</html>
