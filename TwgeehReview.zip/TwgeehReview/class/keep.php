
<?php
header('Content-Type: text/html; charset=UTF-8');
require_once 'config.php';

// استلام البراميترات من رابط الـ GET
$class = $_GET['class'] ?? '';
$subclass = $_GET['subclass'] ?? '';
$subject = $_GET['subject'] ?? '';
$service = $_GET['service'] ?? '';
$search = $_GET['search'] ?? '';

// بناء استعلام SQL ديناميكي بناءً على البراميترات المتاحة
$query = "SELECT * FROM books WHERE 1=1";

if (!empty($class)) {
    $query .= " AND class = '" . $conn->real_escape_string($class) . "'";
}

if (!empty($subclass)) {
    $query .= " AND subclass = '" . $conn->real_escape_string($subclass) . "'";
}

if (!empty($subject)) {
    $query .= " AND subject = '" . $conn->real_escape_string($subject) . "'";
}

if (!empty($service)) {
    $query .= " AND service = '" . $conn->real_escape_string($service) . "'";
}

if (!empty($search)) {
    $query .= " AND title LIKE '%" . $conn->real_escape_string($search) . "%'";
}

// تنفيذ الاستعلام
$books = $conn->query($query)->fetch_all(MYSQLI_ASSOC);

// عرض النتائج
displayBooks($books);

function displayBooks($books) {
    echo '<div class="main-body" id="books-container">';
    foreach ($books as $book) {
        echo '
        <div class="card-header">
            <div class="info-admin">
                <span><i class="fas fa-user me-2"></i> admin</span>
                <span><i class="fas fa-clock mx-2"></i> Jur 12/24</span>
                <span><i class="fa-regular fa-calendar-check mx-2"></i> Oct 2024</span>
            </div>
        </div>
        <div class="card-body">
            <h5 class="card-title">' . htmlspecialchars($book['title']) . '</h5>
            <p class="card-text">
                ' . htmlspecialchars($book['description']) . '
            </p>
            <a href="/admin/uploads/' . htmlspecialchars($book['pdf']) . '" target="_blank">Download PDF</a><br>
            <button data-mdb-ripple-init type="button" class="btn btn-primary" onclick="window.location.href=\'class.php?id=' . $book['id'] . '\';">GET BOOK</button>
        </div>
        <div class="card-footer">' . htmlspecialchars($book['price']) . '</div>
    </div>
    <div class="card">
        <div class="bg-image hover-overlay ripple" data-mdb-ripple-init data-mdb-ripple-color="light">
            <img src="/admin/uploads/' . htmlspecialchars($book['img']) . '" />
            <a>
                <div class="mask" style="background-color: rgba(251, 251, 251, 0.15)"></div>
            </a>
        </div>';
    }
    echo "</div>";
}
?>
