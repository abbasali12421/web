<?php
header('Content-Type: application/json');
require_once 'config.php';

// Read the JSON input or get query parameter
$input = json_decode(file_get_contents('php://input'), true) ?? $_GET;

// Extract the filter parameters
$class = $input['class'] ?? '';  // subclass value
$subject = $input['services1'] ?? '';  // service = subject
$service = $input['subject1'] ?? '';  // subject = service
$titleSearch = $input['k'] ?? '';  // Search keyword

// Initialize params and types
$params = [];
$types = '';

// Build the query dynamically
$query = "SELECT * FROM books WHERE 1=1";

if (!empty($titleSearch)) {
    // If 'k' parameter is provided, search by title
    $query .= " AND title LIKE ?";
    $params[] = '%' . $titleSearch . '%';
    $types .= 's';
} else {
    // Apply strict filtering for all three parameters
    if (!empty($class) && !empty($subject) && !empty($service)) {
        $query .= " AND subclass = ? AND subject = ? AND service = ?";
        $params[] = $class;
        $params[] = $subject;
        $params[] = $service;
        $types .= 'sss';
    } else {
        // If any of the three filters is missing, return no results
        echo json_encode(['html' => '<p>No results found. Please provide all filters: class, subject, and service.</p>']);
        error_log("Input data: " . print_r($input, true));
        exit;
    }
}

// Prepare the statement
$stmt = $conn->prepare($query);
if ($stmt === false) {
    error_log("Prepare failed: " . $conn->error);
    exit;
}

// Bind parameters if applicable
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

// Execute the query and fetch results
if (!$stmt->execute()) {
    error_log("Execute failed: " . $stmt->error);
    exit;
}

$books = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Check if books are empty
if (empty($books)) {
    echo json_encode(['html' => '<p>No results found.</p>']);
    exit;
}

// Generate HTML for the filtered books
$filtered_books_html = '';
foreach ($books as $book) {
    $filtered_books_html .= '
        <div class="card">
            <div class="bg-image hover-overlay ripple" data-mdb-ripple-init data-mdb-ripple-color="light">
                <img src="/admin/uploads/' . htmlspecialchars($book['img']) . '" alt="' . htmlspecialchars($book['filename']) . '" />
                <a>
                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.15)"></div>
                </a>
            </div>
            <div class="card-header">
                <div class="info-admin">
                    <span><i class="fas fa-user me-2"></i> ' . htmlspecialchars($book['author']) . '</span>
                    <span><i class="fas fa-clock mx-2"></i> ' . htmlspecialchars($book['date']) . '</span>
                    <span><i class="fa-regular fa-calendar-check mx-2"></i> ' . htmlspecialchars($book['dater']) . '</span>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title">' . htmlspecialchars($book['title']) . '</h5>
                <p class="card-text">' . htmlspecialchars($book['description']) . '</p>
                <a href="f.php?id=' . htmlspecialchars($book['id']) . '" target="_blank" class="btn btn-primary">View Book</a>
            </div>
            <div class="card-footer">' . htmlspecialchars($book['price']) . '</div>
        </div>';
}

// Return the HTML in JSON format
echo json_encode(['html' => $filtered_books_html]);
?>