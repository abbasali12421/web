<?php
require_once 'config.php';

$offset = $_POST['offset'];
$limit = $_POST['limit'];

$query = "SELECT * FROM posts ORDER BY date DESC LIMIT $offset, $limit";
$result = $conn->query($query);

$posts = array();
while ($post = $result->fetch_assoc()) {
  $posts[] = $post;
}

echo json_encode($posts);
?>