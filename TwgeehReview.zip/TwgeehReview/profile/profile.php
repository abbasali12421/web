<?php
session_start();

// Include the database connection file
include '../config.php';

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

// Get the user's email from the session
$encoded_email = $_SESSION['username'];
$email = base64_decode($encoded_email);

// Fetch user data
$sql = "SELECT * FROM `reg` WHERE email = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    $row = mysqli_fetch_assoc($result);
    $fname = $row['fname'];
    $lname = $row['lname'];
    $city = $row['city'];
    $img = $row['img'];
    $description = $row['description'];
} else {
    $_SESSION['error_message'] = "Error fetching user data: " . mysqli_error($conn);
    header('Location: login.php');
    exit;
}

// Update user data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update-profile'])) {
        $new_fname = $_POST['fname'];
        $new_lname = $_POST['lname'];
        $new_city = $_POST['city'];
        $old_pass = $_POST['old-pass'];
        $new_pass = $_POST['new-pass'];

        // Verify old password
        if (password_verify($old_pass, $row['password'])) {
            // Update user data
            $sql = "UPDATE `reg` SET fname = ?, lname = ?, city = ?, password = ? WHERE email = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "sssss", $new_fname, $new_lname, $new_city, password_hash($new_pass, PASSWORD_DEFAULT), $email);
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success_message'] = "Profile updated successfully.";
                // Update session variables
                $_SESSION['username'] = base64_encode($email);
            } else {
                $_SESSION['error_message'] = "Error updating profile: " . mysqli_error($conn);
            }
        } else {
            $_SESSION['error_message'] = "Old password is incorrect.";
        }
    }

    if (isset($_POST['update-description'])) {
        $new_description = $_POST['description'];

        // Update profile description
        $sql = "UPDATE `reg` SET description = ? WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $new_description, $email);
        if (mysqli_stmt_execute($stmt)) {
            $_SESSION['success_message'] = "Description updated successfully.";
        } else {
            $_SESSION['error_message'] = "Error updating description: " . mysqli_error($conn);
        }
    }

    if (isset($_FILES['newImage']) && $_FILES['newImage']['error'] === UPLOAD_ERR_OK) {
        $img_name = $_FILES['newImage']['name'];
        $img_tmp = $_FILES['newImage']['tmp_name'];

        // Move uploaded file to /uploads/
        $upload_dir = '../uploads/';
        $img_path = $upload_dir . basename($img_name);

        if (move_uploaded_file($img_tmp, $img_path)) {
            // Update image in database
            $sql = "UPDATE `reg` SET img = ? WHERE email = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "ss", $img_name, $email);
            if (mysqli_stmt_execute($stmt)) {
                $_SESSION['success_message'] = "Image updated successfully.";
            } else {
                $_SESSION['error_message'] = "Error updating image: " . mysqli_error($conn);
            }
        } else {
            $_SESSION['error_message'] = "Error uploading image file.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.min.css" rel="stylesheet" />
    <style>
        .grid-area-profile{
            display: grid;
            grid-template-columns: 50% auto;
        }
        @media screen and (max-width:599px) {
          .grid-area-profile{
            display: block;
          }
          .description{
            margin: 0 !important;
            margin-top: 15px !important;
          }
          .btn-edit,.btn-remove{
            padding: 5px !important;
          }
          
        }
        @media screen and (max-width:768px) {
          .grid-area-profile{
            display: block;
          }
          .description{
            margin: 0 !important;
            margin-top: 15px !important;
          }
          .btn-edit,.btn-remove{
            padding: 5px !important;
          }
          
        }
    </style>
    <title>Welcome User</title>
</head>
<body>
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg bg-light navbar-light ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i class="far fa-user-circle mx-3"></i> Profile</a>
    <button class="navbar-toggler" data-mdb-collapse-init type="button" data-mdb-toggle="collapse" data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>
      <ul class="navbar-nav d-flex flex-row me-1">
        <li class="nav-item me-3 me-lg-0">
          <a class="nav-link" href="../index.php"> <i class="fas fa-home mx-2"></i> Home</a>
        </li>
        <li class="nav-item me-3 me-lg-0">
          <a class="nav-link" href="https://t.me/edutawjeeh"><i class="fab fa-telegram mx-2"></i> join us</a>
        </li>
        <li class="nav-item me-3 me-lg-0">
          <a class="nav-link" href="logout.php"><i class="fas fa-right-from-bracket mx-2"></i> Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<!-- Navbar -->
    <div class="m-5 p-3">
        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($_SESSION['error_message']); unset($_SESSION['error_message']); ?>
            </div>
        <?php endif; ?>
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="card p-5">
                <div class="header">
                    <h4><i class="far fa-user-circle"></i> Account Preferences</h4>
                </div>
                <div class="img-edit d-flex">
                    <div class="imgs mx-3">
                        <img src="<?php echo '../uploads/' . htmlspecialchars($img); ?>" class="rounded-circle" width="100px" height="100px" alt="">
                    </div>
                    <div class="controls d-flex flex-column">
                        <label for="fileImg" class="btn btn-edit mt-2 text-white" data-mdb-ripple-init style="background-color: #55acee;" role="button">
                            <i class="far fa-edit me-2"></i>
                            Edit Image
                        </label>
                        <label class="btn btn-remove mt-2 text-white" data-mdb-ripple-init style="background-color: #55acee;" role="button">
                            <i class="far fa-trash-can me-2"></i>
                            Remove Image
                        </label>
                        <input id="fileImg" type="file" name="newImage" class="d-none"/>
                        <button type="submit" name="update-image" class="btn btn-primary mt-2">Update Image</button>
                    </div>
                </div>
                <div class="update-img mt-3 mx-2">
                    <button class="btn btn-primary" type="submit" name="update-image" data-mdb-ripple-init><i class="far fa-image mx-2"></i> Update Image</button>
                </div>
            </div>
        </form>
        <div class="grid-area-profile">
            <div class="profile-editor card p-5 mx-0 mt-3">
                <h4>Profile Details</h4>
                <form action="" method="post">
                    <div class="form-outline mt-2" data-mdb-input-init>
                        <input name="fname" type="text" id="firstname" class="form-control form-control-lg" value="<?php echo htmlspecialchars($fname); ?>" />
                        <label class="form-label" for="fname">First Name</label>
                    </div>
                    <div class="form-outline mt-2" data-mdb-input-init>
                        <input name="lname" type="text" id="lastname" class="form-control form-control-lg" value="<?php echo htmlspecialchars($lname); ?>" />
                        <label class="form-label" for="lname">Last Name</label>
                    </div>
                    <div class="form-outline mt-2">
                        <input name="old-pass" type="password" id="old-pass" class="form-control form-control-lg" />
                        <label class="form-label" for="old-pass">Old Password</label>
                    </div>
                    <div class="form-outline mt-2">
                        <input name="new-pass" type="password" id="new-pass" class="form-control form-control-lg" />
                        <label class="form-label" for="new-pass">New Password</label>
                    </div>
                    <div class="form-outline mt-2">
                        <select class="form-select border border-primary" name="city">
                          <option value="بغداد" <?php echo $city == 'بغداد' ? 'selected' : ''; ?>>بغداد</option>
                          <option value="البصرة" <?php echo $city == 'البصرة' ? 'selected' : ''; ?>>البصرة</option>
                          <option value="نينوى" <?php echo $city == 'نينوى' ? 'selected' : ''; ?>>نينوى</option>
                          <option value="الأنبار" <?php echo $city == 'الأنبار' ? 'selected' : ''; ?>>الأنبار</option>
                          <option value="النجف" <?php echo $city == 'النجف' ? 'selected' : ''; ?>>النجف</option>
                          <option value="كربلاء" <?php echo $city == 'كربلاء' ? 'selected' : ''; ?>>كربلاء</option>
                          <option value="واسط" <?php echo $city == 'واسط' ? 'selected' : ''; ?>>واسط</option>
                          <option value="ديالى" <?php echo $city == 'ديالى' ? 'selected' : ''; ?>>ديالى</option>
                          <option value="ذي قار" <?php echo $city == 'ذي قار' ? 'selected' : ''; ?>>ذي قار</option>
                          <option value="ميسان" <?php echo $city == 'ميسان' ? 'selected' : ''; ?>>ميسان</option>
                          <option value="المثنى" <?php echo $city == 'المثنى' ? 'selected' : ''; ?>>المثنى</option>
                          <option value="بابل" <?php echo $city == 'بابل' ? 'selected' : ''; ?>>بابل</option>
                          <option value="صلاح الدين" <?php echo $city == 'صلاح الدين' ? 'selected' : ''; ?>>صلاح الدين</option>
                          <option value="القادسية (الديوانية)" <?php echo $city == 'القادسية (الديوانية)' ? 'selected' : ''; ?>>القادسية (الديوانية)</option>
                          <option value="كركوك" <?php echo $city == 'كركوك' ? 'selected' : ''; ?>>كركوك</option>
                          <optgroup label="محافظات اقليم كردستان">
                            <option value="اربيل" <?php echo $city == 'اربيل' ? 'selected' : ''; ?>>اربيل</option>
                            <option value="دهوك" <?php echo $city == 'دهوك' ? 'selected' : ''; ?>>دهوك</option>
                            <option value="السليمانية" <?php echo $city == 'السليمانية' ? 'selected' : ''; ?>>السليمانية</option>
                            <option value="none" <?php echo $city == 'none' ? 'selected' : ''; ?>>لست من العراق</option>
                          </optgroup>
                        </select>
                    </div>
                    <div class="update">
                        <button type="submit" name="update-profile" class="update btn btn-primary mt-3" data-mdb-ripple-init>Update Profile</button>
                    </div>
                </form>
            </div>
            <div class="description card mt-3 mx-3 p-5">
               <form action="" method="post">
                <h4>Profile Description</h4>
                <small style="display: inline-block;margin-bottom: 15px;">Here write your description about you</small>
                <div class="form-outline" data-mdb-input-init>
                    <textarea class="form-control" name="description" id="textbox" rows="8" style="resize: none;"><?php echo htmlspecialchars($description); ?></textarea>
                    <label for="textbox" class="form-label">Description</label>
                </div>
                <button class="btn btn-primary mt-3" type="submit" name="update-description">Update Description</button>
               </form>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</body>
</html>
