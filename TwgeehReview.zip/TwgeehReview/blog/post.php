<?php
// Configuration
require_once '../config.php';

// Retrieve post ID from URL parameter
$post_id = $_GET['id'] ?? null;

// Check if post ID is set
if ($post_id) {
    // Retrieve post from database using post ID
    $post = $conn->query("SELECT * FROM posts WHERE id = '$post_id'")->fetch_assoc();

    // Check if post exists
    if ($post) {
        // Display post content
        $title = $post['title'];
        $author = $post['author'];
        $content = $post['content'];
        $date = $post['date']; // Retrieve the date column

        // Display post content here
        ?>
        <div class="title-post container m-3 mt-5 pt-5">
            <h1 class="title"><?php echo $title; ?></h1>
            <div class="details">
                <span><i class="fas fa-clock"></i><span> <?php echo date_format(date_create($date), 'M j, Y'); ?> </span></span>
                <span class="mx-3"><i class="fas fa-user"></i><span> <?php echo $author; ?> </span></span>

            </div>
            <hr>
            <!-- content view -->
            <div class="content mt-5">
                <?php echo $content; ?>
            </div>
            </div>
            <div class="card p-3">
              <hr>
        <div class="card-text fs-6 px-2" style="width: 150px;-radius: 5px;">Share With</div>
        <br>
        <div class="social">
        <button data-mdb-ripple-init class="btn btn-primary" onclick="window.open('https://www.facebook.com/sharer/sharer.php?u=<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
        Facebook <i class="fab fa-facebook"></i>
</button>

<button data-mdb-ripple-init class="btn btn-danger" onclick="window.open('https://telegram.me/share/url?url=<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
    Telegram <i class="fab fa-telegram"></i>
</button>

<button data-mdb-ripple-init class="btn btn-dark" onclick="window.open('https://twitter.com/intent/tweet?url=<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>&text=Check this out! <?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
    Twitter <i class="fab fa-twitter"></i>
</button>

<button data-mdb-ripple-init class="btn btn-success" onclick="window.open('https://api.whatsapp.com/send?text=Check this out! <?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>', '_blank')">
    WhatsApp <i class="fab fa-whatsapp"></i>
</button>

    </div>
        </div>
        <hr>
        <?php
    } else {
        echo "Post not found.";
    }
} else {
    echo "Post ID not specified.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.min.css" rel="stylesheet" />
    <title><?php echo $title; ?></title>
    
</head>
<body>
      <!-- Navbar -->
  <nav class="navbar navbar-expand-lg bg-light navbar-light fixed-top">
    <!-- Container wrapper -->
    <div class="container-fluid">

      <!-- Navbar brand -->
      <a class="navbar-brand" href="../blog.php"><i class="fa-solid fa-quote-right mx-3"></i> Posts</a>

      <!-- Toggle button -->
      <button class="navbar-toggler" data-mdb-collapse-init type="button" data-mdb-toggle="collapse"
        data-mdb-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
        aria-label="Toggle navigation">
        <i class="fas fa-bars"></i>
      </button>

      <!-- Collapsible wrapper -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        </ul>

        <!-- Icons -->
        <ul class="navbar-nav d-flex flex-row me-1">
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="../index.php"><i class="fas fa-home mx-3"></i> <span>Home</span></a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="https://t.me/edutawjeeh"><i class="fab fa-telegram mx-3"></i> <span>join</span></a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="../blog.php"><i class="fas fa-pen-nib mx-3"></i> <span>Blog</span></a>
          </li>
          <li class="nav-item me-3 me-lg-0">
            <a class="nav-link" href="../profile/logout.php"><i class="fa-solid fa-right-from-bracket mx-3"></i> <span>Logout</span></a>
          </li>
        </ul>

        <!-- Search -->
      

      </div>
    </div>
    <!-- Container wrapper -->
  </nav>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.umd.min.js"></script>
</body>
</html>