<?php
session_start();
include "config.php";  // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: admin.php");
    exit;
}

// Fetch user data from the session
$admin_id = $_SESSION['admin_id'];
$admin_username = $_SESSION['admin_username'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
        integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css">
    <script src="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

    <style>
        .editor-preview-side,
        .editor-preview-active-side {
            list-style: circle;
            list-style-position: outside;
            list-style-type: disc;
            padding-left: 30px;

        }

        .active {
            background-color: blue;
        }

        .CodeMirror-sided {
            scroll-behavior: auto !important;
        }

        .grid-system {
            display: grid;
            grid-template-columns: 350px auto 350px;
            column-gap: 15px;
        }

        .grid-col-1,
        .grid-col-2 {
            display: flex;
            flex-direction: column;
            row-gap: 10px;
            justify-content: center;
        }

        .grid-col-3 {
            display: flex;
            flex-direction: column;
            row-gap: 10px;
        }

        .grid-col-3 select {
            border-radius: 6px;
        }

        .text-black {
            color: rgba(228, 227, 227, 0.479);
        }

        .grid-system-posts {
            display: grid;
            grid-template-columns: 400px auto;
            column-gap: 15px;
        }

        .darkmode-btn {
            position: absolute;
            bottom: 0;
            margin: 15px;
            background-color: rgba(58, 54, 54, 0.212);
            border: 0;
            color: white;
            font-size: 25px;
            width: 50px;
            height: 50px;
            cursor: pointer;
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
            border-radius: 50%;

        }

        .darkmode-btn:hover {
            background-color: rgb(20, 20, 20);

        }
        .lightmode{
            background-color: white;
            color: black;
            transition: all 0.3s;

        }
        .lightmode-text{
            color: rgba(0, 0, 0, 0.534) !important;
            transition: all 0.3s;
        }
        .lightmode-input{
            border: 2px solid rgba(0, 0, 0, 0.164);
            color: black;
            background-color: white;
           

        }
        .lightmode-card{
            color: black;
            background-color: white;
            box-shadow: 1px 5px 15px rgba(65, 63, 63, 0.288);
            border: 2px solid rgba(0, 0, 0, 0.164);
        }
        .lightmode-edit{
            background-color: white !important;
            color: black !important;
            border: 1px solid rgba(0, 0, 0, 0.164) !important;

            
        }
        .lightmode-menu-left{
            
            background-color: rgba(18, 93, 255, 0.856);
            border-right: 2px solid rgba(253, 250, 250, 0.178);
            color: black;
            
            backdrop-filter: blur(5px) !important;
        }
        .lightmode-list{
            background-color: rgba(255, 255, 255, 0.034);
           
            color: rgb(255, 252, 252);

        }
        .test{
            color: white;
        }
       
        @media screen and (max-width:599px) {
            .grid-system {
                display: block;

            }
           

        }

        @media screen and (max-width:788px) {

            .grid-system,
            .grid-system-posts {
                display: block;
            }

            .admin-content-panel {
                margin-left: 75px;
            }
            .darkmode-btn{
               margin: 0;
               margin-bottom: 15px;

            }



        }
       
    </style>
    <title>Welcome <?php echo htmlspecialchars($admin_username); ?></title>
</head>

<body>
    
    <main>
        <section class="container">
            <aside class="pad menu-left">
                <div class="logo mb">
                    <!-- logo here -->
                    <a  href="" class="link "><i class="fa-solid fa-gauge-high pad-r testing"></i> <span class="testing">Admin Panel</span></a>
                </div>
                <ul class="d-flex list-none f-col list ul">
                    <li class="br item"><i class="fas fa-book pad"></i> <span>Publish Book</span></li>
                    <li class="br item"><i class="fa-solid fa-feather pad"></i> <span>Posts Management</span></li>
                    <li class="br item"><i class="pad fa-solid fa-flask"></i> <span>Questions</span></li>
                    <li class="br item"><i class="fa-solid fa-gears pad"></i> <span>Settings</span></li>
                </ul>
                <button  class="darkmode-btn"><i class="fas fa-moon"></i></button>
            </aside>
            <article class="ml mt big-content-page">
                <!-- part 1 -->
                <div class="admin-content-panel books">
                    <div class="a-center d-flex between">
                        <div class="TitlePage ">
                            <h1>Publish Book Page</h1>

                        </div>
                        <div class="toolBar-items  d-flex c-gap">

                            <img src="../static/images/log.webp" alt="">

                        </div>
                    </div>
                    <!-- part 2 -->
                    <div class="subtitle">
                        <p class="text-black"
                            style="margin-left: 3px;font-family: sans-serif;color: rgba(206, 199, 199, 0.712);">publish
                            your book on this platform very simple</p>
                    </div>
                    <!-- part 3 -->
                    <div class="main-content-book-page">
                        <div class="details-book">
                            <form style="row-gap: 15px;" class="d-flex f-col c-gap " enctype="multipart/form-data"
                                action="book.php" method="post">
                                <div class="grid-system">
                                    <div class="grid-col-1 card">
                                        <!-- grid system part 1 -->
                                        <h2>Book Details</h2>
                                        <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="book-title">Title</label>
                                            <input class="input-form" type="text" name="BookTitle" id="book-title">
                                        </div>
                                        <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="Author">Author</label>
                                            <input class="input-form" type="text" name="BookAuthor" id="Author">
                                        </div>
                                        <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="book-subname">Subject Name</label>
                                            <input class="input-form" type="text" name="Booksubname" id="book-subname">
                                        </div>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="book-Date">Date</label>
                                            <input class="input-form" type="date" name="BookDate" id="book-Date">
                                        </div>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="book-resource-data">Resource Date</label>
                                            <input class="input-form" type="date" name="BookResourceDate"
                                                id="book-resource-data">
                                        </div>
                                        <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="book-type">Type</label>
                                            <input class="input-form" type="text" name="BookType" id="book-type">
                                        </div>
                                    </div>
                                    <div class="grid-col-2 card">
                                        <h2>Uploads</h2>
                                        <span class="text-black">upload or get your book from telegram or your pc to add
                                            for books</span>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="book-img">Select Book Image</label>
                                            <input class="input-form" type="file" name="bookImage" id="book-img">
                                        </div>

                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="book-file">Select Book File</label>
                                            <input class="input-form" type="file" name="bookfile" id="book-file">
                                        </div>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="book-url">Select Book File</label>
                                            <input class="input-form" type="text" name="bookurl" id="book-url">
                                        </div>
                                        <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="book-Count">Paper Count</label>
                                            <input class="input-form" type="text" name="BookCount" id="book-Count">
                                        </div>
                                        <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="book-size">Size</label>
                                            <input class="input-form" type="text" name="Booksize" id="book-size">
                                        </div>
                                    </div>
                                    <!-- category -->
                                    <div class="grid-col-3 card">
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <h2>Category</h2>
                                            <span class="text-black">select your category from any class to add for
                                                books</span>
                                                <div class="form-input-style j-center d-flex f-col r-gap">
                                            <label for="book-studlvl">Book Class Name</label>
                                            <input class="input-form" type="text" name="Studlvl" placeholder="ضع اسم المرحلة الكتابي" id="book-studlvl">
                                        </div>
                                            <label for="select-class">Select Class Category</label>
                                            <select name="class" class="btn btn-primary select-class" >

                                                <option value="pre">المرحلة الاعدادية</option>
                                                <option value="mid">المرحلة المتوسطة</option>
                                                <option value="first">المرحلة الابتدائية</option>

                                            </select>
                                        </div>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="select-class">Select Subjects</label>
                                            <select name="subject" class="btn btn-primary select-class" >
                                            <option value="den">التربية الإسلامية</option>
                                            <option value="ar">اللغة العربية</option>
                                            <option value="en">اللغة الإنجليزية</option>
                                            <option value="math">الرياضيات</option>
                                            <option value="leve">الأحياء</option>
                                            <option value="ce">الكيمياء</option>
                                            <option value="ph">الفيزياء</option>
                                            <option value="fr">الفرنسي</option>
                                            <option value="eqt">الإقتصاد</option>
                                            <option value="hi">التاريخ</option>
                                            <option value="go">الجغرافية</option>
                                            <option value="earth">علم الأرض</option>
                                            <option value="cp">الحاسوب</option>
                                            <option value="krd">الكردي</option>
                                            <option value="sss">الفلسفة</option>
                                            <option value="mes">علم الاجتماع</option>
                                            <option value="meet">الاجتماعيات</option>
                                            <option value="ak">الأخلاقية</option>
                                            <option value="read">القراءة</option>
                                            <option value="sci">العلوم</option>
                                            <option value="grammar">القواعد</option>

                                            </select>

                                        </div>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="select-class">Select Service</label>
                                            <select name="service" class="btn btn-primary select-class" >
                                            <option value="book">الكتب</option>
                                            <option value="bh">الكتاب المنهجي</option>
                                            <option value="maa">الملازم المنهجية</option>
                                            <option value="mgov">الملازم الوزارية</option>
                                            <option value="mcopy">النسخ الوزارية</option>
                                            <option value="anss">الأجوبة النموذجية الوزارية</option>
                                            <option value="thgov">الثوابت الوزارية</option>
                                            <option value="eqe">ملحقات المادة</option>
                                            <option value="req">المراجعات المركزة</option>
                                            <option value="mo">الملخصات</option>
                                            <option value="pln">مخططات</option>
                                            <option value="knw">ملاحظات مركز الفحص</option>
                                            <option value="dayex">الامتحانات اليومية</option>
                                            <option value="mon">الامتحانات الشهرية</option>
                                            <option value="ep">امتحانات لكل فصل</option>
                                            <option value="ymid">امتحانات نصف السنة</option>
                                            <option value="yend">امتحانات نهاية السنة</option>
                                            <option value="max">الامتحانات الفصلية</option>
                                            <option value="mover">الامتحانات الشاملة</option>
                                            <option value="qpre">اسئلة التمهيدي</option>
                                            <option value="qtv">اسئلة التلفزيون التربوي</option>
                                            <option value="arw">كتاب مؤشر وزاري</option>
                                            </select>



                                        </div>
                                        <div class="form-input-style d-flex f-col r-gap j-center">
                                            <label for="select-class">Select part of Class Category</label>
                                            <select name="subclass" class="btn btn-primary select-class">
                                                <optgroup label="الاعدادية">
                                                    <option value="pre6">السادس الادبي</option>
                                                    <option value="pre5">السادس العلمي</option>
                                                    <option value="pre4">الخامس الادبي</option>
                                                    <option value="pre3">الخامس العلمي</option>
                                                    <option value="pre2">الرابع الادبي</option>
                                                    <option value="pre1">الرابع العلمي</option>


                                                </optgroup>
                                                <optgroup label="المتوسطة">
                                                    <option value="mid3">الثالث المتوسط</option>
                                                    <option value="mid2">الثاني المتوسط</option>
                                                    <option value="mid1">الاول المتوسط</option>
                                                </optgroup>

                                                <optgroup label="الابتدائية">
                                                    <option value="f6">السادس الابتدائي</option>
                                                    <option value="f5">الخامس الابتدائي</option>
                                                    <option value="f4">الرابع الابتدائي</option>
                                                    <option value="f3">الثالث الابتدائي</option>
                                                    <option value="f2">الثاني الابتدائي</option>
                                                    <option value="f1">الاول الابتدائي</option>
                                                </optgroup>
                                            </select>
                                            <input type="hidden" name="price" value="free" id="free">
                                            <input type="hidden" id="book-details" name="details">
                                            <input type="submit" hidden id="submit">
                                        </div>
                                    </div>

                                </div>

                            </form>

                        </div>
                    </div>
                    <!-- part 4 -->
                    <div class="template d-flex card">

                        <div class="controls">
                            <h2>Book Property</h2>
                            <br>
                            <p class="text-black">add more propery to your book like price</p>
                            <div class="label mt mb">Price</div>
                            <div class="d-flex c-gap a-center mt">

                                <button class="btn btn-primary btn-load br" id="freeclick">Free</button>
                                <button class="btn btn-primary btn-load br" id="buyclick">Buy</button>

                            </div>

                            <div class="label mt mb">Description Book</div>
                            <div class="d-flex details-book-textbox">
                                <textarea cols="133" rows="8" class="textbox input-form"></textarea>


                            </div>
                            <div class="submit-all">
                                <button id="btn-publish" class="btn btn-primary mt"
                                    style="border-radius: 4px;background-color: var(--main-color);">Publish
                                    Now</button>
                            </div>
                        </div>
                    </div>
                    <!-- part 5 -->
                </div>
                <div class="admin-content-panel posts">
                    <div class="a-center d-flex between">
                        <div class="TitlePage ">
                            <h1>Posts Management</h1>

                        </div>
                        <div class="toolBar-items  d-flex c-gap">
                            <!-- edit page name -->
                            <button onclick="window.location='posts.php'" class="edit-post"><i class="fas fa-edit"></i></button>

                            <img src="../static/images/log.webp" alt="">

                        </div>
                    </div>
                    <div class="subtitle">
                        <p class="text-black"
                            style="margin-left: 3px;font-family: sans-serif;color: rgba(206, 199, 199, 0.712);">publish
                            your posts on your blog</p>

                    </div>
                    <!-- post management controls -->
                    <div class="posts-details mt">
                        <!-- ajax post send -->
                        <div class="grid-system-posts">
                            <div class="grid-col-post-1 card">
                                <h2>Post Details</h2>
                                <p class="text-black">write about your post</p>
                                <div class="form-input-style mt j-center d-flex f-col r-gap">
                                    <label for="post-title">POST Title</label>
                                    <input class="input-form" type="text" id="post-title">
                                </div>
                                <div class="form-input-style mt j-center d-flex f-col r-gap">
                                    <label for="post-author">Author</label>
                                    <input class="input-form" type="text" id="post-author">
                                </div>
                                <div class="form-input-style mt d-flex f-col r-gap j-center">
                                    <label for="post-date">Date</label>
                                    <input class="input-form" type="date" id="post-date">
                                </div>
                                <div class="form-input-style mt d-flex f-col r-gap j-center">
                                    <label for="post-img">Select Post Image</label>
                                    <input class="input-form" type="file" name="PostImage" id="post-img">
                                </div>
                                <button type="submit"
                                    style="margin-top: 50px; padding: 15px 40px;background-color: var(--main-color);"
                                    class="btn btn-primary mt pad br post-send">Publish</button>
                            </div>
                            <div class="grid-col-post-2 card">
                                <div class="mt">
                                    <label for="editor">
                                        <h2>Article Details</h2>
                                        <p class="text-black">write your post body by markdown or html and css normal
                                        </p>
                                    </label>
                                </div>
                                <div class="mt" style="color: black;background-color: white">

                                    <textarea id="editor"></textarea>
                                </div>


                            </div>
                        </div>




                    </div>
                </div>

                <!-- Author -->
                <div class="admin-content-panel questions">
                    <h1>Comming Soon......</h1>
                </div>
                <div class="admin-content-panel settings">


                    <div class="grid-system-settings">

                        <div class="grid-col-setting-2">
                            <div>
                                <div class="TitlePage ">
                                    <h1 style="font-size: 45px;">Settings</h1>

                                </div>
                            </div>
                            <div class="subtitle">
                                <p class="text-black"
                                    style="margin-left: 3px;font-family: sans-serif;color: rgba(206, 199, 199, 0.712);">
                                    Change
                                    Your Settings</p>
                            </div>
                            <!-- settings admin -->
                            <div class="d-flex f-col">
                                <form class="d-flex f-col" action="" method="post">
                                    <div class="form-input-style mt d-flex f-col r-gap j-center">
                                        <label for="current-password">Current Password</label>
                                        <input class="input-form" type="password" name="CurrentPassword"
                                            id="current-password">
                                    </div>
                                    <div class="form-input-style mt d-flex f-col r-gap j-center">
                                        <label for="new-password">New Password</label>
                                        <input class="input-form" type="password" name="NewPassword" id="new-password">
                                    </div>
                                    <div class="form-input-style mt d-flex f-col r-gap j-center">
                                        <label for="current-email">Current Email</label>
                                        <input class="input-form" type="email" name="CurrentEmail" id="current-email">
                                    </div>
                                    <div class="form-input-style mt d-flex f-col r-gap j-center">
                                        <label for="new-email">New Email</label>
                                        <input class="input-form" type="email" name="NewEmail" id="new-email">
                                    </div>
                                    <button type="submit" class="btn btn-primary mt br"
                                        style="margin-top: 20px;padding: 15px; background-color: var(--main-color);">Change
                                        Your
                                        Data</button>
                                </form>

                            </div>

                        </div>
                    </div>




                </div>
            </article>
        </section>

    </main>

    <script src="js/script.js">
        

    </script>




</body>

</html>