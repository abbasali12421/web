<?php
include('config.php'); // Ensure this path is correct and `config.php` sets up `$conn`
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.min.css" rel="stylesheet" />
    <title>Post Management (View, Edit, Delete)</title>
</head>

<body>
    <div class="header">
        <h1 class="h1 mx-3 mt-5 mb-5">Post Management</h1>
    </div>

    <!-- Alert messages -->
    <div id="alert-danger" class="alert alert-danger mx-5 alert-dismissible" style="display:none;">
        <b>Error: </b><span id="error-message">Try Again</span>
        <button class="btn-close" onclick="closeAlert('alert-danger')" data-mdb-dismiss="alert"></button>
    </div>
    <div id="alert-success" class="alert alert-success mx-5 alert-dismissible" style="display:none;">
        <b>Success: </b><span id="success-message">Operation successful</span>
        <button class="btn-close" onclick="closeAlert('alert-success')" data-mdb-dismiss="alert"></button>
    </div>

    <!-- Posts Table -->
    <table class="table m-3">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Date</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody class="table-light">
            <?php
            // Fetch posts
            if ($conn instanceof mysqli && !$conn->connect_error) {
                $sql = "SELECT id, title, date FROM posts";
                $result = $conn->query($sql);

                if ($result && $result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['title']}</td>
                            <td>{$row['date']}</td>
                            <td><a href='postedit.php?id={$row['id']}' class='btn pt-1 btn-sm btn-secondary btn-rounded' data-mdb-ripple-init data-mdb-ripple-color='red'><i class='fas fa-edit'></i> Edit</a></td>
                            <td><button data-delete-id='{$row['id']}' class='btn pt-1 btn-danger btn-sm btn-rounded' data-mdb-ripple-color='red' data-mdb-ripple-init><i class='fas fa-trash'></i> Delete</button></td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No posts found</td></tr>";
                }

                $conn->close();
            } else {
                echo "<tr><td colspan='5'>Database connection failed</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="return mt-3">
        <button class="mx-3 btn btn-secondary" data-mdb-ripple-init data-mdb-ripple-color="black" onclick="window.location ='../../index.php'">Return to Admin Panel</button>
    </div>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.3.2/mdb.umd.min.js"></script>
    <script>
        // Close alert functions
        function closeAlert(alertId) {
            document.getElementById(alertId).style.display = "none";
        }

        // Handle Delete actions
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('[data-delete-id]').forEach(button => {
                button.addEventListener('click', function() {
                    const id = this.getAttribute('data-delete-id');

                    if (confirm('Are you sure you want to delete this post?')) {
                        fetch('delete_post.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                            },
                            body: `id=${id}`
                        })
                        .then(response => response.text())
                        .then(data => {
                            document.getElementById('success-message').textContent = data;
                            document.getElementById('alert-success').style.display = 'block';
                            location.reload();
                        })
                        .catch(error => {
                            document.getElementById('error-message').textContent = 'Error deleting post';
                            document.getElementById('alert-danger').style.display = 'block';
                        });
                    }
                });
            });
        });
    </script>
</body>

</html>
