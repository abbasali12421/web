<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.css">
    <script src="https://cdn.jsdelivr.net/simplemde/latest/simplemde.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <style>
        body{
            background-color: black;
            color: white;
            padding: 45px;
        }
        .editor-preview-side,.editor-preview-active-side{
            list-style: circle;
            list-style-position: outside;
            list-style-type: disc;
            padding-left: 30px;
        }
        .active {
            background-color: blue;
        }
        .CodeMirror-sided{
             scroll-behavior: auto !important;
        }
    </style>
    <title>Post Editor</title>
</head>
<body>
    <div class="details pad">
        <h1>Post Editor</h1>
        <p>edit your posts by simple feature</p>
    </div>
    <div class="posts-details mt pad">
        <!-- ajax post send -->
        <div class="form-input-style mt j-center d-flex f-col r-gap">
            <label for="post-title">POST Title</label>
            <input class="input-form" type="text"  id="post-title">
        </div>
        <div class="form-input-style mt j-center d-flex f-col r-gap">
            <label for="post-author">Author</label>
            <input class="input-form" type="text"  id="post-author">
        </div>
        <div class="form-input-style mt d-flex f-col r-gap j-center">
            <label for="post-date">Date</label>
            <input class="input-form" type="date"  id="post-date">
        </div>
        <div class="form-input-style mt d-flex f-col r-gap j-center">
            <label for="post-img">Select Post Image</label>
            <input class="input-form" type="file" name="PostImage" id="post-img">
        </div>
        <div class="mt">
            <label for="editor">Article Details</label>
        </div>
        <div class="mt" style="color: black;background-color: white">
            <textarea id="editor"></textarea>
        </div>
        
        <!-- Hidden field to store the post ID -->
        <input type="hidden" id="post-id" value="1"> <!-- Replace "1" with the dynamic post ID if applicable -->

        <button type="submit"
                style="margin-top: 15px; padding: 15px 40px;background-color: var(--main-color);"
                class="btn btn-primary mt pad br post-send">Publish</button>
    </div>

    <script>
        // Initialize the SimpleMDE editor
        var simplemde = new SimpleMDE({ 
            element: $("#editor")[0], 
            placeholder: "Enter Your Post Content.....",
            promptURLs: true,
            renderingConfig: {
                codeSyntaxHighlighting: true,
            },
            shortcuts: {
                drawTable: "Cmd-Alt-T"
            },
            showIcons: ["code", "table", "horizontal-rule", "heading-bigger", "heading-smaller", "side-by-side", "strikethrough"]
        });

        // Ajax class to handle sending data
        class Ajax {
            constructor(phpscript, formData) {
                fetch(phpscript, {
                    method: "POST",
                    body: formData
                })
                    .then(response => response.json())
                    .then(data => console.log(data))
                    .catch(error => console.error('Error:', error));
            }
        }

        // When the "Publish" button is clicked
        $(".post-send").click(function () {
            var markdownContent = simplemde.value();
            var htmlContent = simplemde.options.previewRender(markdownContent);

            // Create a new FormData object
            var formData = new FormData();
            formData.append("post-id", $("#post-id").val()); // Get the post ID from the hidden field
            formData.append("post-title", $("#post-title").val());
            formData.append("post-author", $("#post-author").val());
            formData.append("post-date", $("#post-date").val());
            formData.append("post-content", htmlContent);

            // Append the selected file (if any)
            var fileInput = document.getElementById('post-img');
            var file = fileInput.files[0];
            if (file) {
                formData.append("post-img", file);
            }

            // Send the FormData object using Ajax
            var ajax = new Ajax("pedit.php", formData);
        });
    </script>
</body>
</html>
