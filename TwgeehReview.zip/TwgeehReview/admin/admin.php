<?php
include "config.php"; // Database connection

session_start();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = isset($_POST['mail']) ? trim($_POST['mail']) : '';
    $password = isset($_POST['pass']) ? trim($_POST['pass']) : '';

    // Prepare the statement to prevent SQL injection
    $query = $conn->prepare("SELECT * FROM admin WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $result = $query->get_result();
    $admin = $result->fetch_assoc();

    // Check if an admin with that email exists
    if ($admin) {
        // If using plain-text passwords, compare directly
        if ($password === $admin['password']) {
            // Set session or redirect to dashboard
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_username'] = $admin['username'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"
    integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style/login.css">
    <title>Admin Panel - Login</title>
</head>
<body>
    <div class="grid-system">
        <div class="img-left">
            <img src="img/3651039.webp"/>
        </div>
        <div class="controls">
            <h2>Login to Dashboard</h2>
            <div class="read-controls">
                <?php if (isset($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
                <form action="" method="post">
                    <input type="email" name="mail" placeholder="Enter Your E-mail" id="email" required>
                    <input type="password" name="pass" placeholder="Enter Your Password" id="password" required>
                    <a href="#">Forget Password?</a>
                    <button type="submit">Login</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
