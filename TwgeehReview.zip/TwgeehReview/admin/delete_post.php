<?php
require_once 'config.php'; // Include the configuration file

$id = $_POST['id'];

$sql = "DELETE FROM posts WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Post deleted successfully";
} else {
    echo "Error deleting post: " . $conn->error;
}

$conn->close();
?>
