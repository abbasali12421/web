<?php
// Include database configuration file
require_once 'config.php';

// Configuration
$uploadDir = 'uploads/';
$allowedImageTypes = array('jpg', 'jpeg', 'png', 'gif');
$allowedFileTypes = array('pdf', 'docx', 'doc', 'txt');

// Create the uploads directory if it does not exist
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Function to validate file type
function validateFileType($file, $allowedTypes) {
    $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
    return in_array(strtolower($fileExtension), $allowedTypes);
}

// Function to upload file
function uploadFile($file, $uploadDir, $fieldName) {
    $fileName = basename($file['name']);
    $uploadPath = $uploadDir . $fileName;
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return $fileName;
    } else {
        return null;
    }
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $title = trim(isset($_POST['BookTitle']) ? $_POST['BookTitle'] : '');
    $author = trim(isset($_POST['BookAuthor']) ? $_POST['BookAuthor'] : '');
    $subname = trim(isset($_POST['Booksubname'])? $_POST['Booksubname'] : '');
    $btype = trim(isset($_POST['BookType'])? $_POST['BookType'] : '');
    $count = trim(isset($_POST['BookCount']) ? $_POST['BookCount'] : '');
    $bsize = trim(isset($_POST['Booksize']) ? $_POST['Booksize'] : '');
    $date = trim(isset($_POST['BookDate']) ? $_POST['BookDate'] : '');
    $resourceDate = trim(isset($_POST['BookResourceDate']) ? $_POST['BookResourceDate'] : '');
    $bookUrl = trim(isset($_POST['bookurl']) ? $_POST['bookurl'] : '');
    $price = trim(isset($_POST['free']) ? $_POST['free'] : '');
    $description = trim(isset($_POST['details']) ? $_POST['details'] : '');
    $bookImage = $_FILES['bookImage'];
    $bookFile = $_FILES['bookfile'];
    $class = $_POST['class'];
    $subclass = $_POST['subclass'];
    $subject = $_POST['subject'];
    $service = $_POST['service'];
    $studlvl = $_POST['Studlvl'];


    // Validate form data
    $errors = array();
    if (empty($title)) {
        $errors[] = 'Title is required';
    }
    if (empty($subname)) {
        $errors[] = 'Subname is required';
    }
    if (empty($btype)) {
        $errors[] = 'book type is required';
    }
    if (empty($count)) {
        $errors[] = 'Paper Count is required';
    }
    if (empty($bsize)) {
        $errors[] = 'Book Size is required';
    }
    if (empty($author)) {
        $errors[] = 'Author is required';
    }
    if (empty($date)) {
        $errors[] = 'Date is required';
    }
    if (empty($resourceDate)) {
        $errors[] = 'Resource Date is required';
    }
    if (empty($bookUrl)) {
        $errors[] = 'Book URL is required';
    }
    if (empty($price)) {
        $errors[] = 'Price is required';
    }
    if (empty($description)) {
        $errors[] = 'Description is required';
    }
    if (empty($class)) {
        $errors[] = 'Class is required';

    }if (empty($subclass)) {
        $errors[] = 'SubClass is required';

    }if (empty($subject)) {
        $errors[] = 'Subject is required';

    }if (empty($service)) {
        $errors[] = 'Service is required';

    }
    if (empty($studlvl)) {
        $errors[] = 'Class Book Name is required';
    }
    // Validate and upload book image
    if ($bookImage['size'] > 0) {
        if (validateFileType($bookImage, $allowedImageTypes)) {
            $bookImageName = uploadFile($bookImage, $uploadDir, 'bookImage');
        } else {
            $errors[] = 'Invalid book image type';
        }
    } else {
        $errors[] = 'Book image is required';
    }

    // Validate and upload book file
    if ($bookFile['size'] > 0) {
        if (validateFileType($bookFile, $allowedFileTypes)) {
            $bookFileName = uploadFile($bookFile, $uploadDir, 'bookFile');
        } else {
            $errors[] = 'Invalid book file type';
        }
    } else {
        $errors[] = 'Book file is required';
    }

    // If no errors, insert data into database
    if (count($errors) == 0) {
        $query = "INSERT INTO books (title, author, date, dater, book_url, price, description, img, pdf, class, subclass, subject, service, size, count, filename, type, studlvl) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssssssssssssssssss", $title, $author, $date, $resourceDate, $bookUrl, $price, $description, $bookImageName, $bookFileName, $class, $subclass, $subject, $service, $bsize, $count, $subname, $btype, $studlvl);
        $stmt->execute();
        $stmt->close();
        $conn->close();
        header('Location: dashboard.php'); // Redirect to index.php after successful insertion
        exit;
    } else {
        // Display errors
        foreach ($errors as $error) {
            echo "<p>$error</p>";
        }
    }
}
?>